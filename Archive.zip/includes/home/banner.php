<!-- ================================ Slider ================================ -->
    <section id="banner" class="container mx-auto pt-16 max-w-[1240px] px-3">
        <div>
            <h1 class="md:text-5xl text-3xl font-bold text-[#707070] max-w-lg">#1 Marketplace For Voice Over</h1>
            <img src="../../assets/img/banner-slider/banner.png" alt="" class="mt-5 w-full max-w-xs">
            <p class="text-[#707070] max-w-md mt-4">Sign up in seconds. Post a job for free. It's quick and easy to hire Professional and global voice actors for any creative project.</p>
        </div>
    </section>
<!-- ============================##== Slider ==##============================ -->