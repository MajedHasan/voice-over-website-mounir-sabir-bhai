<?php 
    require("./config/config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= $pageTitle; ?></title>

    <!-- Font Awesome Icon CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <!-- Font Awesome Icon Not CDN -->
    <link rel="stylesheet" href="/assets/css/fontAwesome.css">

    <!-- Diasy UI CDN -->
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.6.0/dist/full.min.css" rel="stylesheet" type="text/css" />
    <!-- Diasy UI Not CDN -->
    <link rel="stylesheet" href="/assets/css/daisyUI.css">

    <!-- Swiper JS CDN -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />


    <?php
    
        if($currentPage = "Home"){
            echo '<link rel="stylesheet" href="./assets/css/categoryMenu.css">';
        }

    ?>

    <!-- Style CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">


    <!-- Search Handler Scripts -->
    <script src="/assets/js/searchHandler.js"></script>


</head>
<body>

    <!-- ================================ Header ================================ -->
    <header id="header" class="border-b border-b-sky-800 sticky top-0 bg-white z-[999]">
        <div class="container mx-auto px-3 md:px-0 flex flex-row items-center justify-between py-3 gap-4 xl:max-w-[1240px]">
            <a href="/" class="text-sky-700 text-3xl font-bold flex">
                V<span class="lg:flex hidden">oices</span>
            </a>
            <div class="relative flex-1 flex justify-center">
                <div class="flex items-center rounded-full py-2 px-4 bg-slate-200 md:w-[400px] w-full gap-3">
                    <i class="fa-solid fa-magnifying-glass text-xl text-gray-500"></i>
                    <input type="text" id="searchInput" class="outline-none flex-1 rounded bg-transparent text-gray-600 placeholder:text-gray-500" placeholder="Search for Talent or Packages...">
                    <i class="fa-solid fa-filter text-xl text-gray-500 cursor-pointer"></i>
                </div>
            </div>
            <div class="lg:flex items-center gap-4 hidden">
                <a href="./login.php" class="border border-sky-700 py-1 px-4 rounded text-sky-700 font-semibold hover:bg-sky-700 hover:text-white transition-all">Log In</a>
                <a href="./signup.php" class="bg-sky-700 rounded py-1 px-4 text-white text-md font-semibold border-sky-700 border hover:bg-gray-50 hover:text-sky-700 transition-all">Sign Up</a>
            </div>
            <button id="mobile-menu-open-btn" class="lg:hidden flex text-2xl cursor-pointer">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>
        <div id="mobile-menu" class="fixed top-0 left-0 right-0  bottom-0 bg-slate-100/95 py-8 px-6 lg:invisible visible hidden transition-all z-[9999]">
            <div class="container mx-auto">
                <div class="flex items-center justify-between gap-4">
                    <a href="/" class="text-sky-700 text-2xl font-bold">Voices</a>
                    <button id="mobile-menu-close-btn" class="text-2xl cursor-pointer">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                <div class="flex flex-col gap-2 mt-6">
                    <a href="./login.php" class="border border-sky-700 py-1 px-4 rounded text-sky-700 font-semibold hover:bg-sky-700 hover:text-white transition-all text-center">Log In</a>
                    <a href="./signup.php" class="bg-sky-700 rounded py-1 px-4 text-white text-md font-semibold border-sky-700 border hover:bg-gray-50 hover:text-sky-700 transition-all text-center">Sign Up</a>
                </div>
            </div>
        </div>
    </header>
    <!-- ============================##== Header ==##============================ -->


    <!-- ================================ Header ================================ -->
    <!-- ============================##== Header ==##============================ -->
