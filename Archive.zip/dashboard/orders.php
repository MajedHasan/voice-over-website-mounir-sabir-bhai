<?php 

    $pageTitle = "Orders";
    $currentPage = "Orders";

    include("../includes/admin/header.php");
?>

    <div class="flex-1 h-full"></div>

<?php 
    include("../includes/admin/footer.php");
?>