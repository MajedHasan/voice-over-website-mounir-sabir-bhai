<?php 

    $pageTitle = "Contact";
    $currentPage = "Contact";

    include("../includes/admin/header.php");

?>

    <div class="flex-1 h-full flex justify-center items-center">
       
    </div>

<?php 
    include("../includes/admin/footer.php");
?>