<?php 

    $pageTitle = "Dashboard";

    include("../includes/admin/header.php");
?>



<?php 
    include("../includes/admin/footer.php");
?>