<?php 
    $pageTitle = "Home | #1 Voice Over Marketplace";
    $currentPage = "Home";
    include("./includes/common/header.php");

    include("./includes/common/categoryMenu.php");
?>


    <!-- ================================ Banner ================================ -->
    <section id="banner" class="bg-gradient-to-r from-sky-700 to-violet-500 pt-40 pb-60">
        <div class="container mx-auto xl:px-0 px-3 flex items-center justify-between md:flex-row flex-col gap-12 xl:max-w-[1240px]">
            <div class="flex-1">
                <h1 class="md:text-5xl text-3xl font-bold text-white md:text-left text-center">#1 Marketplace For Voice Over</h1>
                <p class="md:text-2xl text-md text-white mt-6 md:text-left text-center">Sign up in seconds. Post a job for free. It's quick and easy to hire professional and global voice actors for any creative project.</p>
                <div class="flex items-center gap-4 mt-4 md:justify-start justify-center">
                    <a href="#" class="rounded bg-white py-2 px-6 text-black border transition-all text-lg font-semibold hover:bg-sky-700 hover:border-white hover:text-white">
                        Find Talent
                    </a>
                    <a href="#" class="rounded bg-white py-2 px-6 text-black border transition-all text-lg font-semibold hover:bg-sky-700 hover:border-white hover:text-white">
                        Find Work
                    </a>
                </div>
            </div>
            <div class="flex-1"></div>
        </div>
    </section>
    <!-- ============================##== Banner ==##============================ -->


    <!-- ================================ Header ================================ -->
    <!-- ============================##== Header ==##============================ -->

<?php include("./includes/common/footer.php") ?>